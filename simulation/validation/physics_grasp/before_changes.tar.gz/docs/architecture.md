# Piper Project Architecture

## Overall Goal

Develop a Piper robotic arm system with separate simulation and real-robot workspaces.

## Simulation

Planned scope:
- Robot description and simulation model
- ROS 2 interfaces
- Visualization
- Simulation controllers
- Offline testing

## Real Robot

Planned scope:
- Hardware communication
- Robot driver integration
- Robot control interfaces
- Diagnostics
- Supervised hardware validation

## Shared Components

Shared runtime code has not yet been defined.

If a component needs to be used by both workspaces, document the design decision before introducing a shared package or synchronizing source code.

## 2026-10-11: brain-robot-arm import decision

The user authorized importing `https://github.com/bcwsyn/brain-robot-arm` into both workspaces. Pin the import to commit `6ebd0c53ca830ac4071b8e64fcc1954dbf5a8cf1`.

- Keep an exact tracked-file source archive and a source-to-destination checksum manifest under `shared/upstream/brain_robot_arm/`. This is reference material, not a ROS overlay or shared runtime package.
- Import reusable description, message, MoveIt, perception and controller sources as independent copies into each workspace. Do not use cross-workspace symlinks or source the other workspace's install directory. Record all import adaptations in the manifest.
- Put Gazebo/MuJoCo packages, scenes and simulation entry points in `simulation/`. Exclude CAN/USB drivers and physical-arm adapters; reject physical backend selection in the simulation controller/executor copies.
- Put Piper and camera drivers, physical adapter, real profiles and real launch files in `real_robot/`. Disable imported default motor/motion/grasp permissions and recorded observation-calibration claims. Remove Gazebo build requirements from the real application package.
- Preserve old machine-specific installation, maintenance and control scripts as non-default legacy reference tools; do not execute them during import.
- Preserve historical documents/evidence under `docs/imports/brain_robot_arm/`, clearly distinguishing them from validation on this machine. Do not activate imported agent configuration or inherit old hardware authorizations.
- Keep package names stable within each workspace. Because the workspaces contain overlapping package names, build and source only one workspace at a time. Future synchronization requires an explicit reviewed change with checks in the affected workspace.

This decision implements workspace separation and provenance only. Runtime compatibility, camera calibration, physical grasping and the complete research goals remain to be validated.

## 2026-10-12: simulation pick-and-place control ownership

Use one explicit handoff between the visual controller and the existing grasp executor. The visual FSM owns Servo during observation/search/alignment. The executor calls `/visual_search_controller/claim_grasp_control`, confirms Servo stop, and waits for fresh, stable measured joint positions before planning/executing. During executor ownership, visual jog, reacquisition and a new start are suppressed; stop, emergency stop and feedback-loss checks remain active. Returning control requires a new start request; it does not automatically restart Servo.

Keep the target object in the MoveIt world scene. Permit only the gripper assembly's target contact, attach during transport, restore the released object and original allowed-collision matrix afterward. Recompute each executed Cartesian segment from measured state, retaining MoveIt's existing start-state tolerance. The default visual profiles use direct alignment followed by finite side-grasp candidates instead of the old cup leveling sequence.

`flow_demo=true` is an explicit nonphysical demonstration mode: object gravity is disabled, the pose plugin drives motion, and Gazebo object contact forces are disabled to avoid fighting forced poses. It preserves MoveIt collision geometry and a geometric capture gate. A future physical mode must remove pose following, enable gravity/contact, and validate retention; merely setting `flow_demo=false` does not implement that mode.

Separate scene readiness from executor readiness. Use `/brain_robot_{ball_pick,pick_place}/scene_ready` for generated scenes and `/brain_robot_grasp/scene_ready` for executor preparation. Completion means release, safe retreat and return to the named `zero` posture, followed by `COMPLETE`.

Use a Gazebo-only persistent controller bootstrap with a DDS discovery window, process-local asynchronous Fast DDS publication, and local transport settings in the bounded validator. Keep original imported provenance hashes immutable; record subsequent source changes and test evidence separately under `simulation/validation/step1/`.

## 2026-10-12: one-terminal visual simulation sessions

Expose separate ball and cylinder shell entry points backed by `simulation/scripts/visual_sim_console.py`. Load only the simulation overlay automatically; use ROS domain 83, localhost-only discovery, a dedicated Gazebo master port 11483, and a shared exclusive session lock. Refuse an occupied session instead of terminating foreign processes.

The console orchestrates existing launch files and calls only visual start/stop and scene reset services. It does not compute grasp coordinates or publish joint trajectories; the existing visual FSM/executor ownership protocol remains responsible for motion. Require an explicit S key for each run. Accept normal reset only while idle or after full completion; wait for the new scene readiness, actual object origin and measured zero joints before accepting another run. After an interrupted/faulted run, R replaces the owned simulation stack to clear attachment/follow state.

Own Gazebo server, GUI, MoveIt, RViz, scene, detector and task process groups. Detect child exit, bound startup/service/reset/task waits, restore terminal settings on exit, and stop/reap only recorded groups. Keep the parent ROS context alive through keyboard interruption so it can request stop before cleanup. Save component logs, state events and run measurements per session.

Use an RViz PlanningScene display with automatic raw/detection Image panels and a saved docking layout. Start RViz as an independently monitored process; use process-local Mesa software rendering for this desktop's GLX failure, leaving Gazebo rendering and system drivers unchanged. This session UI does not add physical grasping or change the accepted simulation algorithms.

## 2026-10-12: randomized visual scenes and selectable placement

Extend the same single-terminal simulation console with seeded uniform target positions in a bounded, previously tested tabletop neighborhood. Generate one per-scene YAML for both the scene manager and follower. Normal R replaces only the owned scene/follow process group; do not leave a follower initialized with the previous object's position. Preserve ownership, home-feedback and scene-position gates. Keep interrupted-run full-stack reset.

Expose two placement presets through atomic XY parameter updates on the simulation grasp executor. Validate finite double values and bounded placement coordinates, reject updates while the executor is working or its visual state is not idle, and snapshot accepted values when the worker starts. Validation callbacks have no cache side effects. The UI also rejects changes from S until the task has finished.

Publish the actual image-stamped, world-frame camera point when the executor locks its target. This is an output for measurement, not a ground-truth control input. Compare it with the actual static Gazebo object center; distinguish horizontal surface-to-center discrepancy from vertical surface bias. Keep known model height/collision geometry and the existing camera-directed grasp pipeline explicit. This phase does not implement unknown-shape grasping or camera calibration evaluation.

Store each scene profile, independent component logs, localization snapshot timestamps, object trajectories and trial metrics. Write session JSON through fsync plus atomic replacement. Headless batch trials require explicit count and seed, declare their scene/zone plan before movement, and stop at the first moving-trial failure. A bounded retry is allowed only for an explicit pre-motion fresh-joint discovery refusal; retain that refusal separately. Export per-trial/per-localization CSV and aggregate statistics without mixing prior static-scene trials or physical-grasp claims.
