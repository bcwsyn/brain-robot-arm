# Piper 仿真工作区

2026-10-12 后续已加入随机起点、A/B 放置区选择和锁定定位记录；小球 10/10、圆柱体 10/10 预定随机流程试验通过，见[随机视觉取放验收](../docs/下一步_随机视觉取放开发与验收.md)。仍为跟随式流程，不能作为物理抓取成功率。

源码来自 `brain-robot-arm@6ebd0c53ca83`，已分类导入。2026-10-11 已完成 7 个包构建、39 个算法单元测试和默认小球/圆柱体运行检查，当时默认抓取流程未通过验收。2026-10-12 已修复控制交接并实现完整取放，四个静态起点的小球 20/20、圆柱体 20/20 跟随式流程试验通过。失败处理与详细结果见[第一步开发与验收](../docs/第一步_单物品闭环开发与验收.md)。目标为 ROS 2 Humble；当前配置使用 **Gazebo Classic**，不能直接按 Fortress 插件启动。

## 内容

| 路径 | 用途 |
| --- | --- |
| src/piper_description | 机器人 URDF/Xacro、网格、坐标与可视化资源 |
| src/piper_msgs | Piper 消息与服务定义 |
| src/piper_with_gripper_moveit | 带夹爪 MoveIt 配置 |
| src/piper_no_gripper_moveit | 不带夹爪 MoveIt 配置 |
| src/piper_gazebo | Gazebo 控制器和夹爪镜像脚本 |
| src/brain_robot_pick_place | 桌面场景、固定取放、RGB-D 检测、视觉搜索和抓取执行 |
| src/brain_robot_ball_pick | 红球仿真场景与检测/搜索配置 |
| scripts/ | 已将默认路径改为当前工作区的仿真启动与只读监控脚本 |
| optional_src/ | MuJoCo 参考包，由 `COLCON_IGNORE` 排除，暂不参与构建 |

此工作区没有 Piper CAN 驱动、真机 jog 适配器或实体相机驱动。控制器与抓取执行器副本会拒绝选择物理后端。依然应与真实机器人使用独立终端/ROS 会话，不能连接或加载真实驱动。

## 推荐操作：一个终端观看相机取放

在本目录直接运行 `./scripts/run_ball_visual_sim.sh`（小球）或 `./scripts/run_cylinder_visual_sim.sh`（圆柱体）。程序自动加载环境、Gazebo、MoveIt、RViz 相机画面、场景与视觉任务，等待按键开始；不需要另外开终端或安装依赖。

目标起点随机生成；`1/2` 选择 A/B 放置区，`S` 开始，`R` 在完成后随机复位再抓，`X` 停止，`Q` 或 `Ctrl+C` 统一退出，不用回车。运行中不允许改放置区、复位或重复开始；停止/故障后 `R` 会重新加载本次仿真。一次只运行一个入口，日志位于 `log/visual_sim/`。

完整操作、状态说明与后续研发范围见[第一步报告第 5.2 节](../docs/第一步_单物品闭环开发与验收.md#52-推荐一个终端按键完成整套可视化仿真)。原多终端方式保留用于调试。

使用 `--seed 20261012` 可重现随机起点顺序。随机起点、定位统计、数据导出和验收见[随机视觉取放报告](../docs/下一步_随机视觉取放开发与验收.md)；记录位于 `validation/visual_randomization/`。

## 构建与验证

主要依赖包括 ROS 2 Humble、MoveIt 2/Servo、ros2_control/轨迹控制器、Gazebo Classic 的 ROS 插件、OpenCV、cv_bridge、TF 和消息同步。已有依赖能完成编译和启动，但本机 Pilz 与 MoveIt 核心版本不一致、CHOMP 缺库；存在 Python 用户目录 NumPy 2 与 ROS cv_bridge 的兼容问题。现已明确仅启用 OMPL。历史失败与修复验收见下方报告，未安装或修改系统依赖。

安装依赖需另行批准。准备就绪后，仅在本目录构建：

```bash
cd /home/young1x/robot_projects/piper_robot/simulation
source /opt/ros/humble/setup.bash
colcon build --symlink-install
```

已有检查命令：`colcon test --packages-select brain_robot_pick_place`、`colcon test-result --verbose`。现有 45 个算法用例通过（6 个 CTest 目标，colcon 汇总为 51 项）。控制交接、实测起点重算、斜侧抓和释放回零已实现；端到端结果单独记录，不能由单元测试推断。

`start_piper_sim.sh` 将加载虚拟控制器、Gazebo 与 MoveIt；`start_brain_robot_demo.sh` 增加红杯场景、检测与搜索；红球演示在另一个脚本中。原验收使用单独的有界验证脚本；当前交互演示优先使用上方两个新入口。启动前应说明具体程序与运动效果；历史脚本的宽泛旧进程自动清理调用已改为检测冲突后退出。

`scripts/validate_sim_grasp.py` 支持 `ball`、`cup-known`、`cup-vision`，原始基线记录在 `validation/runs/`，第一步开发与验收记录在 `validation/step1/`。支持 `--repetitions`、`--scene-params-file` 和 `--negative-case`；`run_step1_trials.py` 按保存的计划重复测试，遇到失败立即停下并保留结果。`validation/grasp_validation.world` 提供实际物品状态观测；小球冻结跟踪配置仅用于对照，不覆盖默认配置。无窗口入口为 `wrist_camera_gazebo.launch.py gui:=false` 和 `piper_moveit.launch.py start_rviz:=false`；默认仍显示窗口。无窗口 Gazebo 的 RGB-D 渲染仍需可用的图形渲染环境。

第一步实现、验收判据和新复现命令见[第一步开发与验收](../docs/第一步_单物品闭环开发与验收.md)。历史基线、证据链接与后续分阶段研发任务见[仿真验证及下一步规划](../docs/小球与圆柱体仿真验证及下一步规划.md)。

包内原 README 与 `UPSTREAM_SIM_README.md` 保留上游说明，旧路径和命令仅供参考，以本工作区说明为准。物品跟随模型是流程模拟，需要另行实现接触/摩擦验证后才能统计物理抓取。

完整来源、适配记录与规划差距见 [导入审查](../docs/imports/brain_robot_arm/导入审查.md)。
