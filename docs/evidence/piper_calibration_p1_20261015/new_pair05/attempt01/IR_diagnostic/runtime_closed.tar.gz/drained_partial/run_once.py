"""One authorized IR/depth observation; no motion, no recovery, no camera setters.

Only enable_ir=True, ir_height=400 in isolated launch; depth/RGB and production unchanged.
Sources cleanup included in <=30s camera bound; SDK preflight is receive-only.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
TEST=Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
sys.path.insert(0,str(TEST))
from collect_calibration_p0 import read_can,healthy_window

jobs=[];camera_start=None;factory=None;controls=None
report={'diagnostic_only':True,'motion_commands_sent':False,'camera_setters_called':False,
        'only_runtime_parameter_override':{'enable_ir':True,'ir_height':400},'automatic_reopen':False,
        'events':[],'error':None,'camera_session_started':False}

def save(name,value):
    with (ROOT/name).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)

def start(name,args):
    stream=(ROOT/(name+'.log')).open('xb')
    proc=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    jobs.append((name,proc,stream))
    report['events'].append({'name':name,'argv':args,'pid':proc.pid,'epoch':time.time()})
    return proc

try:
    sources=[TEST/name for name in ['native_depth_diagnostic.py','collect_ir_depth_diagnostic.py',
                                   'collect_static_rgbd.py','calibration_readonly_feedback.py']]
    sources += [Path('/home/johnwick/ros2_ws/install/astra_camera/share/astra_camera')/p
                for p in ['launch/astra.launch.py','params/astra_params.yaml']]
    save('source_SHA_before.json',{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    sdk=start('sdk_before',['/usr/bin/python3',str(TEST/'collect_calibration_sdk.py'),
                           '--output',str(ROOT/'sdk_before.json'),'--duration-s','6'])
    report['SDK_original_returncode']=sdk.wait(timeout=10)
    rows=json.loads((ROOT/'sdk_before.json').read_text())['samples']
    fresh=[row for row in rows if row['fresh_after_passive_connection']]
    assert len(fresh)>=30,'No fresh telemetry; no camera session'
    original=json.loads(Path('/mnt/hgfs/ub/docs/evidence/piper_calibration_p1_20261015/new_pair05/attempt01/observe_capture/verification.json').read_text())['last_fresh_feedback']['q_driver_rad']
    report['actual_q_delta_from_original_observe_rad']=[a-b for a,b in zip(fresh[-1]['q_driver_rad'],original)]
    assert max(map(abs,report['actual_q_delta_from_original_observe_rad']))<=.001,'Pose changed; fixed-reference diagnostic stopped'
    before=read_can();time.sleep(.2);after=read_can()
    save('can_before.json',{'before':before,'after':after,'healthy':healthy_window(before,after)})
    assert healthy_window(before,after),'CAN not active receiving; no recovery attempted'
    start('feedback',['/usr/bin/python3',str(TEST/'calibration_readonly_feedback.py'),
                      '--duration-s','40','--output',str(ROOT/'feedback.json')])
    observer=start('observer',['/usr/bin/python3',str(TEST/'collect_ir_depth_diagnostic.py'),
                               '--output',str(ROOT/'streams'),'--duration-s','26'])
    # Let original 3s real-q history accumulate before camera startup load.
    time.sleep(3.3)
    report['feedback_history_subscription_before_camera_s']=3.3
    camera_start=time.monotonic();report['camera_start_epoch']=time.time();report['camera_session_started']=True
    start('camera',['ros2','launch',str(ROOT/'ir_diagnostic.launch.py')])
    while time.monotonic()-camera_start<4.:
        if 'SENSOR_DEPTH is started' in (ROOT/'camera.log').read_text(errors='replace'):break
        time.sleep(.05)
    start('color',['/opt/ros/humble/lib/image_tools/cam2image','--ros-args','-p','burger_mode:=false',
                   '-p','device_id:=0','-p','frequency:=5.0','-p','width:=320','-p','height:=240',
                   '-p','frame_id:=camera_color_optical_frame','-r','image:=/camera/color/image_raw'])
    code='from pathlib import Path; from collect_static_rgbd import collect; import sys; sys.exit(collect(Path(sys.argv[1]),16.,3,settle_s=3.,stop_on_feedback_loss=True,max_bytes=4<<20))'
    capture=start('capture',['/usr/bin/python3','-c',code,str(ROOT/'capture')])
    while time.monotonic()-camera_start<26.:
        if factory is None and (ROOT/'streams/depth/ready.json').exists():
            report['real_depth_ready']=json.loads((ROOT/'streams/depth/ready.json').read_text())
            factory=start('factory',['/usr/bin/python3','/home/johnwick/brain_robot_logs/calibration_stage1_activated_20261014.kfNDAQ/capture_factory_metadata.py',str(ROOT/'factory.json')])
        if controls is None and (ROOT/'streams/depth/ready.json').exists() and (ROOT/'streams/ir/ready.json').exists():
            report['real_ir_ready']=json.loads((ROOT/'streams/ir/ready.json').read_text())
            remaining=min(16.,24.-(time.monotonic()-camera_start))
            if remaining>=1.:
                controls=start('controls',['/usr/bin/python3',str(TEST/'collect_depth_controls.py'),
                                           '--output',str(ROOT/'depth_controls.json'),'--duration-s',str(remaining)])
        if observer.poll() is not None and capture.poll() is not None and (factory is None or factory.poll() is not None) and (controls is None or controls.poll() is not None):break
        time.sleep(.05)
except BaseException as exc:
    report['error']=repr(exc)
finally:
    for name,proc,stream in jobs:
        if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
    deadline=time.monotonic()+1.5
    while any(p.poll() is None for _,p,_ in jobs) and time.monotonic()<deadline:time.sleep(.02)
    for name,proc,stream in jobs:
        if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL)
        report['events'].append({'name':name,'returncode':proc.wait(timeout=.5),'epoch':time.time()})
        stream.close()
    report['all_owned_sources_exited']=all(p.poll() is not None for _,p,_ in jobs)
    report['camera_elapsed_s']=None if camera_start is None else time.monotonic()-camera_start
    report['within_30s_camera_bound']=camera_start is None or report['camera_elapsed_s']<=30.
    report['factory_started']=factory is not None;report['controls_started']=controls is not None
    report['camera_stop_epoch']=time.time()
    save('source_SHA_after.json',{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    save('can_after.json',read_can())
    save('execution.json',report)
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['error'] is None and report['within_30s_camera_bound'] else 2)
