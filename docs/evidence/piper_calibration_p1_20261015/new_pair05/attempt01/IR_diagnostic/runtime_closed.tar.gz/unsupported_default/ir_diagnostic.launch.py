"""One-shot diagnostic launch; deployed production launch/params untouched."""
from launch import LaunchDescription
from launch_ros.actions import ComposableNodeContainer
from launch_ros.descriptions import ComposableNode
from ament_index_python.packages import get_package_share_directory
import yaml


def generate_launch_description():
    with open(get_package_share_directory('astra_camera')+'/params/astra_params.yaml') as stream:
        params=yaml.safe_load(stream)
    # The sole runtime parameter difference from the deployed original launch.
    params['enable_ir']=True
    descriptions=[ComposableNode(package='astra_camera',plugin='astra_camera::OBCameraNodeFactory',
                                 name='camera',namespace='camera',parameters=[params])]
    for name,plugin in [('point_cloud_xyz','PointCloudXyzNode'),('point_cloud_xyzrgb','PointCloudXyzrgbNode')]:
        descriptions.append(ComposableNode(package='astra_camera',plugin='astra_camera::'+plugin,
                                          name=name,namespace='camera'))
    return LaunchDescription([ComposableNodeContainer(name='astra_camera_container',namespace='',
        package='rclcpp_components',executable='component_container',
        composable_node_descriptions=descriptions,output='screen')])
