"""Execute only approved pair05 release/original observe; no new motion planner.

Original ROS services, original adapter gripper input and controller prepare.
No DisableArm, reset, firmware or direct SDK motion calls. Finite owned jobs.
"""
import json
import os
from pathlib import Path
import signal
import subprocess
import time

import rclpy
from rclpy.qos import qos_profile_sensor_data
from rcl_interfaces.srv import SetParameters, GetParameters
from rcl_interfaces.msg import Parameter, ParameterValue, ParameterType
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from std_srvs.srv import Trigger
from piper_msgs.srv import Enable
import yaml

ROOT = Path(__file__).resolve().parent
TESTS = Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
TASK = Path('/home/johnwick/piper_ws/src/brain_robot_ball_pick/config/cube_task_real.yaml')
NAMES = [f'joint{i}' for i in range(1, 7)]
report = {'scope': 'pair05 in-place open, original observe, stop before SEARCH, A only',
          'commands': [], 'events': [], 'error': None, 'observe_reached': False,
          'opened': False, 'hardware_enable_or_disable_requested': False,
          'production_modified': False}
jobs = []
latest = None
first_command = None
reason = ''
armed = False


def start(name, argv):
    stream = (ROOT / (name + '.log')).open('xb')
    proc = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    jobs.append((name, proc, stream))
    report['commands'].append({'name': name, 'argv': argv, 'pid': proc.pid, 'epoch': time.time()})
    return proc


def spin():
    rclpy.spin_once(node, timeout_sec=.03)


def wait(predicate, seconds, label):
    until = time.monotonic() + seconds
    while time.monotonic() < until:
        spin()
        if predicate():
            return
    raise TimeoutError(label)


def external(name, argv, seconds):
    proc = start(name, argv)
    wait(lambda: proc.poll() is not None, seconds, name)
    report['events'].append({'name': name, 'exit_code': proc.returncode, 'epoch': time.time()})
    return proc.returncode


def receive(message):
    global latest
    values = dict(zip(message.name, message.position))
    if all(name in values for name in NAMES):
        latest = {'epoch': time.time(), 'q': [values[n] for n in NAMES],
                  'gap_m': values.get('gripper'),
                  'source_stamp_ns': str(message.header.stamp.sec * 10**9 + message.header.stamp.nanosec)}


def command(message):
    global first_command
    if first_command is None:
        values = dict(zip(message.name, message.position))
        if all(n in values for n in NAMES):
            first_command = {'epoch': time.time(), 'q': [values[n] for n in NAMES]}


def receive_reason(message):
    global reason
    reason = message.data
    report['events'].append({'reason': reason, 'epoch': time.time()})
    print('CONTROLLER:', reason, flush=True)


def call(path, kind, request, deadline=18):
    client = node.create_client(kind, path)
    wait(lambda: client.service_is_ready(), deadline, path + ' discovery')
    future = client.call_async(request)
    wait(future.done, deadline, path + ' response; request NOT retried')
    response = future.result()
    report['events'].append({'service': path, 'response': str(response), 'epoch': time.time()})
    node.destroy_client(client)
    return response


def trigger(path):
    response = call(path, Trigger, Trigger.Request())
    if not response.success:
        raise RuntimeError(path + ': ' + response.message)


def stop_owned(proc):
    if proc.poll() is None:
        os.killpg(proc.pid, signal.SIGINT)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=3)
    return proc.returncode


rclpy.init()
node = rclpy.create_node('calibration_pair05_authorized_session')
node.create_subscription(JointState, '/joint_states_feedback', receive, qos_profile_sensor_data)
node.create_subscription(JointState, '/joint_commands', command, qos_profile_sensor_data)
node.create_subscription(String, '/brain_robot_visual_control/reason', receive_reason, 10)
jaw = node.create_publisher(JointState, '/brain_robot_grasp/gripper_command', 10)
try:
    packet = json.loads((ROOT / 'sdk_before.json').read_text())
    measured = [s for s in packet['samples'] if s['fresh_after_passive_connection']][-1]
    assert all(measured['enabled'])
    config = yaml.safe_load(TASK.read_text())
    lo = config['grasp_lift_executor']['ros__parameters']['real_trajectory_joint_min']
    hi = config['grasp_lift_executor']['ros__parameters']['real_trajectory_joint_max']
    assert all(a <= q <= b for a, q, b in zip(lo, measured['q_driver_rad'], hi))
    subprocess.run(['ip', '-details', '-statistics', '-json', 'link', 'show', 'can0'],
                   stdout=(ROOT / 'can_before.json').open('xb'), check=True)
    start('driver', ['/usr/bin/python3', '-c', "import sys; sys.path.append('/home/johnwick/.local/lib/python3.10/site-packages'); from piper.piper_ctrl_single_node import main; main()", '--ros-args', '--log-level', 'WARN',
                    '-p', 'can_port:=can0', '-p', 'auto_enable:=false', '-p', 'gripper_exist:=true',
                    '-r', 'joint_states_single:=/joint_states', '-r', 'joint_ctrl_single:=/joint_commands'])
    start('visual', ['/usr/bin/python3', str(ROOT / 'original_observe_launch.py')])
    start('bag', ['ros2', 'bag', 'record', '-o', str(ROOT / 'motion_witness_bag'),
                  '/joint_states_feedback', '/joint_commands', '/brain_robot_grasp/arm_trajectory',
                  '/brain_robot_grasp/gripper_command', '/brain_robot_visual_control/state',
                  '/brain_robot_visual_control/reason', '/brain_robot_control/adapter_armed'])
    wait(lambda: latest is not None and time.time() - latest['epoch'] < .5, 18, 'fresh original driver feedback')
    assert max(abs(a-b) for a,b in zip(latest['q'], measured['q_driver_rad'])) <= .001
    report['before_arm_feedback'] = dict(latest)
    # Original driver requires its own enable service even if motors are already enabled.
    enabled = call('/enable_srv', Enable, Enable.Request(enable_request=True))
    report['hardware_enable_or_disable_requested'] = True
    report['only_original_enable_true_requested'] = True
    assert enabled.enable_response
    wait(lambda: latest is not None and time.time() - latest['epoch'] < .5,
         26, 'fresh post-enable feedback')
    report['after_original_enable_feedback'] = dict(latest)
    param = Parameter(name='stop_after_observe', value=ParameterValue(type=ParameterType.PARAMETER_BOOL, bool_value=True))
    request = SetParameters.Request(parameters=[param])
    result = call('/visual_search_controller/set_parameters', SetParameters, request)
    assert result.results[0].successful
    result = call('/visual_search_controller/get_parameters', GetParameters,
                  GetParameters.Request(names=['stop_after_observe']))
    assert result.values[0].bool_value
    report['stop_after_observe_readback'] = True
    trigger('/piper_jog_adapter/enable_motion')
    report['feedback_at_arm'] = dict(latest)
    trigger('/piper_jog_adapter/arm')
    armed = True
    wait(lambda: first_command is not None, 5, 'first actual adapter command')
    report['first_command'] = first_command
    # Existing adapter must hold measured start, not clip the known out-of-bounds arm incident.
    assert max(abs(a-b) for a,b in zip(first_command['q'], report['feedback_at_arm']['q'])) <= .001
    # Cameras remain stopped during authorized release/prepare. Same original
    # control interfaces, no changed motion/quality thresholds. RGB-D follows
    # only after these control processes exit, as a separate receive-only stage.
    report['camera_sources_during_motion'] = False
    wait(lambda: jaw.get_subscription_count() >= 1, 8, 'original adapter gripper subscriber')
    wait(lambda: latest is not None and time.time() - latest['epoch'] < .5,
         5, 'fresh feedback before original gripper command')
    report['before_open_feedback'] = dict(latest)
    opening = JointState()
    opening.name = ['gripper']
    opening.position = [.1]
    jaw.publish(opening)
    report['events'].append({'published': '/brain_robot_grasp/gripper_command', 'position_m': .1, 'epoch': time.time()})
    wait(lambda: latest['gap_m'] is not None and abs(latest['gap_m'] - .1) <= .003
         and time.time() - latest['epoch'] < .5, 15, 'actual original 100mm open tolerance')
    report['opened'] = True
    report['opened_feedback'] = dict(latest)
    trigger('/visual_search_controller/start')
    wait(lambda: 'OBSERVE_POSE_REACHED_STOPPED_BEFORE_SEARCH' in reason or 'FAILED' in reason,
         305, 'original observation completion')
    assert 'OBSERVE_POSE_REACHED_STOPPED_BEFORE_SEARCH' in reason
    report['observe_reached'] = True
    report['observe_feedback'] = dict(latest)
    trigger('/piper_jog_adapter/disarm')
    armed = False
    external('sdk_observe', ['/usr/bin/python3', str(TESTS / 'collect_calibration_sdk.py'),
             '--output', str(ROOT / 'sdk_observe.json'), '--duration-s', '6'], 12)
except BaseException as exc:
    report['error'] = repr(exc)
    print('SESSION STOP:', repr(exc), flush=True)
finally:
    if armed:
        for path in ['/visual_search_controller/stop', '/piper_jog_adapter/disarm']:
            try:
                trigger(path)
            except BaseException as exc:
                report['events'].append({'stop_service': path, 'error': repr(exc)})
    for name, proc, stream in reversed(jobs):
        report['events'].append({'name': name, 'final_exit_code': stop_owned(proc), 'epoch': time.time()})
        stream.close()
    report['all_owned_sources_exited'] = all(p.poll() is not None for _,p,_ in jobs)
    report['last_received_feedback'] = latest
    subprocess.run(['ip', '-details', '-statistics', '-json', 'link', 'show', 'can0'],
                   stdout=(ROOT / 'can_after.json').open('xb'), check=False)
    (ROOT / 'execution_session.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['observe_reached'] and report['error'] is None else 2)
