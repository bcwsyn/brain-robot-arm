"""Finite receive-only observation capture after control stack has exited."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
TESTS = Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
sys.path.insert(0, str(TESTS))
from calibration_p0_quality import review_frame, summarize
from review_depth_registration import calibration, read_config

jobs = []
report = {'receive_only': True, 'motion_commands_sent': False, 'error': None,
          'events': [], 'formal_capture_started': False}


def start(name, argv):
    stream = (ROOT / (name + '.log')).open('xb')
    proc = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    jobs.append((name, proc, stream))
    report['events'].append({'name': name, 'argv': argv, 'epoch': time.time()})
    return proc


def stop(proc):
    if proc.poll() is None:
        os.killpg(proc.pid, signal.SIGINT)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=3)
    return proc.returncode


def run(name, argv, limit):
    proc = start(name, argv)
    try:
        rc = proc.wait(timeout=limit)
    except subprocess.TimeoutExpired:
        rc = stop(proc)
    report['events'].append({'name': name, 'exit_code': rc, 'epoch': time.time()})
    return rc


try:
    start('A_depth', ['ros2', 'launch', 'astra_camera', 'astra.launch.py'])
    for _ in range(24):
        if 'SENSOR_DEPTH is started' in (ROOT / 'A_depth.log').read_text(errors='replace'):
            break
        time.sleep(.5)
    argv = ['/opt/ros/humble/lib/image_tools/cam2image', '--ros-args', '-p', 'burger_mode:=false',
            '-p', 'device_id:=0', '-p', 'frequency:=5.0', '-p', 'width:=320', '-p', 'height:=240',
            '-p', 'frame_id:=camera_color_optical_frame', '-r', 'image:=/camera/color/image_raw']
    color = start('A_color', argv)
    for _ in range(16):
        if (ROOT / 'A_color.log').read_text(errors='replace').count('Publishing image #') >= 3:
            break
        time.sleep(.5)
    if (ROOT / 'A_color.log').read_text(errors='replace').count('Publishing image #') < 3:
        report['initial_color_stop_rc'] = stop(color)
        start('A_color_reopen', argv)
        time.sleep(5)
    start('A_bridge', ['/usr/bin/python3', str(TESTS / 'calibration_readonly_feedback.py'),
                      '--duration-s', '120', '--output', str(ROOT / 'A_bridge.json')])
    run('A_factory', ['/usr/bin/python3', '/home/johnwick/brain_robot_logs/calibration_stage1_activated_20261014.kfNDAQ/capture_factory_metadata.py',
                     str(ROOT / 'A_factory.json')], 18)
    rc = run('A_preview', ['/usr/bin/python3', str(TESTS / 'collect_static_rgbd.py'),
                          '--output', str(ROOT / 'A_preview'), '--duration-s', '18',
                          '--frames', '3', '--settle-s', '3'], 24)
    if rc != 0:
        raise RuntimeError('Preview incomplete; do not continue with stale/missing inputs')
    config = Path('/home/johnwick/piper_ws/src/brain_robot_ball_pick/config/cube_detector.yaml')
    params = read_config(config)
    camera = calibration(params)
    rows = [json.loads(s) for s in (ROOT / 'A_preview/observer.jsonl').read_text().splitlines()]
    quality = []
    for row in rows:
        result, witness = review_frame(row, params, camera)
        quality.append(result)
        if row['snapshot'] == 1:
            import cv2
            assert cv2.imwrite(str(ROOT / 'A_preview_witness.png'), witness)
    report['preview_summary'] = summarize(quality)
    report['preview_frames'] = quality
    print(json.dumps(report['preview_summary']), flush=True)
    # Save one original finite raw batch when a complete measured face is
    # already supported. Table/top uncertainty stays in the ORIGINAL report;
    # this changes acquisition scheduling only, never frame qualification.
    if not any(row['face_quality_candidate'] for row in quality):
        report['stop_reason'] = 'preview_no_complete_measured_face_stop'
    else:
        report['formal_capture_started'] = True
        run('A_capture', ['/usr/bin/python3', str(TESTS / 'collect_calibration_p0.py'),
                         '--output', str(ROOT / 'observation'), '--config', str(config),
                         '--max-batches', '1', '--frames-per-batch', '60', '--seconds-per-batch', '45'], 115)
except BaseException as exc:
    report['error'] = repr(exc)
finally:
    for name, proc, stream in reversed(jobs):
        report['events'].append({'name': name, 'final_exit_code': stop(proc), 'epoch': time.time()})
        stream.close()
    report['all_owned_sources_exited'] = all(proc.poll() is not None for _,proc,_ in jobs)
    subprocess.run(['ip', '-details', '-statistics', '-json', 'link', 'show', 'can0'],
                   stdout=(ROOT / 'A_can_after.json').open('xb'), check=False)
    (ROOT / 'A_execution.json').write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['formal_capture_started'] and report['error'] is None else 2)
