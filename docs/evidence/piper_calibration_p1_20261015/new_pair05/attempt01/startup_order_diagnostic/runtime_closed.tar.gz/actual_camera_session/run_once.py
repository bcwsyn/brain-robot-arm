"""One authorized continuous camera session, <=30s including source cleanup.

No robot controller/adapter, no interface recovery, no camera setters. Existing
receive-only bridge and unmodified original RGB-D collector are reused.
"""
import json
import hashlib
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
TEST=Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
sys.path.insert(0,str(TEST))
from collect_calibration_sdk import summarize
from collect_calibration_p0 import read_can, healthy_window

jobs=[]
report={'read_only':True,'motion_commands_sent':False,'camera_setters_called':False,
        'automatic_reopen':False,'events':[],'error':None,'camera_session_started':False}
camera_start=None
factory=None

def save(name,obj):
    with (ROOT/name).open('x') as stream:
        json.dump(obj,stream,indent=2,allow_nan=False)

def start(name,args):
    stream=(ROOT/(name+'.log')).open('xb')
    proc=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    jobs.append((name,proc,stream))
    report['events'].append({'name':name,'argv':args,'pid':proc.pid,'epoch':time.time()})
    return proc

try:
    files=[TEST/name for name in ['collect_depth_controls.py','native_depth_diagnostic.py',
           'collect_static_rgbd.py','calibration_readonly_feedback.py']]
    save('source_SHA_before.json',{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    proc=start('sdk_before',['/usr/bin/python3',str(TEST/'collect_calibration_sdk.py'),
                             '--output',str(ROOT/'sdk_before.json'),'--duration-s','6'])
    rc=proc.wait(timeout=10)
    packet=json.loads((ROOT/'sdk_before.json').read_text())
    rows=packet['samples']
    usable=[r for r in rows if r['fresh_after_passive_connection']]
    report['sdk_before_rc']=rc
    assert len(usable)>=30,'No fresh feedback; no camera session started'
    accepted=[]
    for i in range(len(rows)):
        for j in range(i+30,len(rows)+1):
            part=rows[i:j]
            if all(r['fresh_after_passive_connection'] for r in part):
                quality=summarize(part)
                if quality['static_three_seconds_and_thirty_samples']:
                    accepted.append({'slice':[i,j],'quality':quality})
    report['original_static_slice']=max(accepted,key=lambda x:x['slice'][1]-x['slice'][0]) if accepted else None
    report['SDK_static_quality_is_metadata_not_camera_start_gate']=True
    report['original_frame_collector_static_and_freshness_rules_unchanged']=True
    original=json.loads(Path('/mnt/hgfs/ub/docs/evidence/piper_calibration_p1_20261015/new_pair05/attempt01/observe_capture/verification.json').read_text())['last_fresh_feedback']['q_driver_rad']
    report['pre_q_delta_rad']=[a-b for a,b in zip(usable[-1]['q_driver_rad'],original)]
    assert max(map(abs,report['pre_q_delta_rad']))<=.001,'Pose changed from fixed-reference observation'
    before=read_can();time.sleep(.2);after=read_can()
    save('can_before.json',{'before':before,'after':after,'healthy':healthy_window(before,after)})
    assert healthy_window(before,after),'No active receiving existing CAN; no recovery'
    start('feedback',['/usr/bin/python3',str(TEST/'calibration_readonly_feedback.py'),
                      '--duration-s','40','--output',str(ROOT/'feedback.json')])
    camera_start=time.monotonic()
    report['camera_start_epoch']=time.time()
    report['camera_session_started']=True
    start('depth',['ros2','launch','astra_camera','astra.launch.py'])
    controls=start('controls',['/usr/bin/python3',str(TEST/'collect_depth_controls.py'),
                               '--output',str(ROOT/'depth_controls.json'),'--duration-s','24',
                               '--native-output',str(ROOT/'native')])
    report['native_depth_independent_of_RGB']=True
    report['RGB_depth_startup_order']='Wait at most4s for original depth started log, then open RGB once; no restart'
    while time.monotonic()-camera_start<4.:
        if 'SENSOR_DEPTH is started' in (ROOT/'depth.log').read_text(errors='replace'):
            break
        time.sleep(.05)
    start('color',['/opt/ros/humble/lib/image_tools/cam2image','--ros-args','-p','burger_mode:=false',
                   '-p','device_id:=0','-p','frequency:=5.0','-p','width:=320','-p','height:=240',
                   '-p','frame_id:=camera_color_optical_frame','-r','image:=/camera/color/image_raw'])
    report['factory_policy']='No GET until native/ready.json proves actual same-stamp depth and Info with fresh feedback'
    code='from pathlib import Path; from collect_static_rgbd import collect; import sys; sys.exit(collect(Path(sys.argv[1]),16.,3,settle_s=3.,stop_on_feedback_loss=True,max_bytes=4<<20))'
    capture=start('capture',['/usr/bin/python3','-c',code,str(ROOT/'capture')])
    while time.monotonic()-camera_start<26.:
        if factory is None and (ROOT/'native/ready.json').exists():
            report['actual_native_ready']=json.loads((ROOT/'native/ready.json').read_text())
            factory=start('factory',['/usr/bin/python3','/home/johnwick/brain_robot_logs/calibration_stage1_activated_20261014.kfNDAQ/capture_factory_metadata.py',str(ROOT/'factory.json')])
        if controls.poll() is not None and capture.poll() is not None and (factory is None or factory.poll() is not None):
            break
        time.sleep(.05)
    report['end_reason']='original_collectors_finished' if controls.poll() is not None and capture.poll() is not None else 'single_session_26s_deadline'
except BaseException as exc:
    report['error']=repr(exc)
finally:
    # Signal all owned processes together, not one blocking timeout per source.
    for name,proc,stream in jobs:
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGINT)
    grace=time.monotonic()+1.5
    while any(proc.poll() is None for _,proc,_ in jobs) and time.monotonic()<grace:
        time.sleep(.02)
    for name,proc,stream in jobs:
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGKILL)
        rc=proc.wait(timeout=.5)
        report['events'].append({'name':name,'exit_code':rc,'epoch':time.time()})
        stream.close()
    report['all_owned_sources_exited']=all(proc.poll() is not None for _,proc,_ in jobs)
    report['factory_started']=factory is not None
    if factory is None:
        save('factory_deferred.json',{'queried':False,'reason':'No real native depth/Info ready marker; no factory GET sent'})
    report['camera_session_upper_bound_s']=None if camera_start is None else time.monotonic()-camera_start
    report['within_30s_camera_bound']=camera_start is None or report['camera_session_upper_bound_s']<=30.
    report['camera_stop_epoch']=time.time()
    try:
        save('can_after.json',read_can())
    except Exception as exc:
        report['can_after_error']=repr(exc)
    save('execution.json',report)
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['error'] is None and report['within_30s_camera_bound'] else 2)
