"""One 8s camera-off receive-only feedback check; no recovery/control APIs."""
import json
from pathlib import Path
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parent
TEST=Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
sys.path.insert(0,str(TEST))
from collect_calibration_p0 import read_can
before=read_can();began=time.time()
result=subprocess.run(['/usr/bin/python3',str(TEST/'collect_calibration_sdk.py'),
                       '--output',str(ROOT/'sdk.json'),'--duration-s','8'],capture_output=True,text=True,timeout=12)
with (ROOT/'check.json').open('x') as stream:
    json.dump({'before':before,'after':read_can(),'began_epoch':began,'end_epoch':time.time(),
               'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
               'camera_started':False,'commands_sent':False,'recovery_attempted':False},stream,indent=2)
print((ROOT/'check.json').read_text(),flush=True)
