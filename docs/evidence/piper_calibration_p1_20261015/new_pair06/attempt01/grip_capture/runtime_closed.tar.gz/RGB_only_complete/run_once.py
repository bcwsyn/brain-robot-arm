"""B-only RGB+actual telemetry; no depth source, RPC, motion or recovery."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
ROOT=Path(__file__).resolve().parent
TEST=Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
sys.path.insert(0,str(TEST))
from collect_calibration_p0 import read_can,healthy_window
jobs=[];began=time.monotonic()
report={'pair_id':'new_pair06','capture_role':'manual_grip_B','read_only':True,
        'motion_commands_sent':False,'camera_setters_called':False,'depth_started':False,
        'events':[],'error':None,'operator_grip_and_same_position_confirmed':True,
        'operator_quote':'已完成','original_static_or_freshness_thresholds_modified':False}
def put(name,value):
    with (ROOT/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False)
def start(name,args,env=None):
    stream=(ROOT/(name+'.log')).open('xb')
    proc=subprocess.Popen(args,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,env=env)
    jobs.append((name,proc,stream));report['events'].append({'name':name,'pid':proc.pid,'argv':args,'epoch':time.time()})
    return proc
sources=[TEST/name for name in ('capture_scale_frames.py','calibration_readonly_feedback.py')]
put('source_SHA_before.json',{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
try:
    b=read_can();time.sleep(.2);a=read_can();put('can_before.json',{'before':b,'after':a,'healthy':healthy_window(b,a)})
    assert healthy_window(b,a),'Existing link not actively receiving; no recovery'
    start('feedback',['/usr/bin/python3',str(TEST/'calibration_readonly_feedback.py'),
                      '--duration-s','25','--output',str(ROOT/'feedback.json')])
    env=os.environ.copy();env.update(BRAIN_ROBOT_CAPTURE_MAX_SECONDS='12',BRAIN_ROBOT_CAPTURE_MAX_MB='4')
    recorder=start('recorder',['/usr/bin/python3',str(TEST/'capture_scale_frames.py'),str(ROOT/'capture')],env)
    time.sleep(3.3)
    report['subscription_precedes_color_s']=3.3
    start('color',['/opt/ros/humble/lib/image_tools/cam2image','--ros-args','-p','burger_mode:=false',
                   '-p','device_id:=0','-p','frequency:=5.0','-p','width:=320','-p','height:=240',
                   '-p','frame_id:=camera_color_optical_frame','-r','image:=/camera/color/image_raw'])
    recorder.wait(timeout=16)
except BaseException as exc:report['error']=repr(exc)
finally:
    for name,proc,stream in jobs:
        if proc.poll() is None:os.killpg(proc.pid,signal.SIGINT)
    deadline=time.monotonic()+1.5
    while any(p.poll() is None for _,p,_ in jobs) and time.monotonic()<deadline:time.sleep(.02)
    for name,proc,stream in jobs:
        if proc.poll() is None:os.killpg(proc.pid,signal.SIGKILL)
        report['events'].append({'name':name,'returncode':proc.wait(timeout=.5),'epoch':time.time()});stream.close()
    report['all_owned_sources_exited']=all(p.poll() is not None for _,p,_ in jobs)
    report['elapsed_s']=time.monotonic()-began
    put('can_after.json',read_can())
    put('source_SHA_after.json',{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources})
    put('execution.json',report)
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['error'] is None else 2)
