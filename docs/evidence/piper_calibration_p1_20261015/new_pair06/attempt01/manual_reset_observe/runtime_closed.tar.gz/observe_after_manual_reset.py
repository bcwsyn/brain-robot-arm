"""Bounded P1 service orchestration; original driver/adapter/controller only.

User confirmed manual reset and requested original observation return/capture.
No new trajectories, no gripper/disable/reset commands, no camera during motion.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

import rclpy
from rclpy.qos import qos_profile_sensor_data
from rcl_interfaces.srv import SetParameters, GetParameters
from rcl_interfaces.msg import Parameter, ParameterValue, ParameterType
from sensor_msgs.msg import JointState
from std_msgs.msg import String
from std_srvs.srv import Trigger
from piper_msgs.srv import Enable
import yaml

ROOT = Path(__file__).resolve().parent
TESTS = Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
TASK = Path('/home/johnwick/piper_ws/src/brain_robot_ball_pick/config/cube_task_real.yaml')
ADAPTER = Path('/home/johnwick/piper_ws/src/brain_robot_pick_place/scripts/piper_jog_adapter.py')
NAMES = [f'joint{i}' for i in range(1, 7)]
report = {'scope': 'new_pair06 after operator manual reset: enable and original observe only',
          'operator_manual_reset_confirmed': True, 'cube_unchanged_during_reset': None,
          'commands': [], 'events': [], 'error': None, 'observe_reached': False,
          'gripper_commands_sent': False, 'reset_or_disable_sent': False,
          'production_modified': False, 'candidate_fix_deployed': False}
jobs = []
latest, first_command, reason, armed = None, None, '', False


def start(name, argv):
    stream = (ROOT / (name + '.log')).open('xb')
    proc = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    jobs.append((name, proc, stream))
    report['commands'].append({'name': name, 'argv': argv, 'pid': proc.pid, 'epoch': time.time()})
    return proc


def wait(predicate, seconds, label):
    until = time.monotonic() + seconds
    while time.monotonic() < until:
        rclpy.spin_once(node, timeout_sec=.03)
        if predicate():
            return
    raise TimeoutError(label)


def call(path, kind, request, seconds=18):
    client = node.create_client(kind, path)
    try:
        wait(client.service_is_ready, seconds, path + ' discovery')
        future = client.call_async(request)
        wait(future.done, seconds, path + ' response; not retried')
        response = future.result()
        report['events'].append({'service': path, 'response': str(response), 'epoch': time.time()})
        return response
    finally:
        node.destroy_client(client)


def trigger(path):
    result = call(path, Trigger, Trigger.Request())
    if not result.success:
        raise RuntimeError(path + ': ' + result.message)


def receive(message):
    global latest
    values = dict(zip(message.name, message.position))
    if all(name in values for name in NAMES):
        latest = {'epoch': time.time(), 'q': [values[n] for n in NAMES],
                  'gap_m': values.get('gripper'),
                  'source_stamp_ns': str(message.header.stamp.sec * 10**9 + message.header.stamp.nanosec)}


def receive_command(message):
    global first_command
    values = dict(zip(message.name, message.position))
    if first_command is None and all(name in values for name in NAMES):
        first_command = {'epoch': time.time(), 'q': [values[n] for n in NAMES]}


def receive_reason(message):
    global reason
    reason = message.data
    report['events'].append({'reason': reason, 'epoch': time.time()})
    print('CONTROLLER:', reason, flush=True)


def can_snapshot(name):
    subprocess.run(['ip', '-details', '-statistics', '-json', 'link', 'show', 'can0'],
                   stdout=(ROOT / name).open('xb'), check=True)


def stop_owned(proc):
    if proc.poll() is None:
        os.killpg(proc.pid, signal.SIGINT)
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            proc.wait(timeout=3)
    return proc.returncode


def sdk(name):
    path = ROOT / (name + '.json')
    proc = start(name, ['/usr/bin/python3', str(TESTS / 'collect_calibration_sdk.py'),
                         '--output', str(path), '--duration-s', '6'])
    wait(lambda: proc.poll() is not None, 12, name)
    report['events'].append({'name': name, 'exit_code': proc.returncode})
    packet = json.loads(path.read_text())
    rows = [s for s in packet['samples'] if s['fresh_after_passive_connection']]
    if not rows:
        raise RuntimeError(name + ': no fresh SDK feedback')
    return rows[-1]


rclpy.init()
node = rclpy.create_node('calibration_pair06_authorized_observe_after_reset')
node.create_subscription(JointState, '/joint_states_feedback', receive, qos_profile_sensor_data)
node.create_subscription(JointState, '/joint_commands', receive_command, qos_profile_sensor_data)
node.create_subscription(String, '/brain_robot_visual_control/reason', receive_reason, 10)
try:
    report['adapter_sha256'] = hashlib.sha256(ADAPTER.read_bytes()).hexdigest()
    assert report['adapter_sha256'] == 'a5074c614fcc1b7f57854e2693e689337577567dde0ca7765470df52fa1347d8'
    packet = json.loads((ROOT / 'sdk_after_manual_reset.json').read_text())
    assert packet['quality']['static_three_seconds_and_thirty_samples']
    measured = [s for s in packet['samples'] if s['fresh_after_passive_connection']][-1]
    config = yaml.safe_load(TASK.read_text())
    limits = config['grasp_lift_executor']['ros__parameters']
    lo, hi = limits['real_trajectory_joint_min'], limits['real_trajectory_joint_max']
    assert all(a <= q <= b for a, q, b in zip(lo, measured['q_driver_rad'], hi))
    report['initial_measured'] = measured
    can_snapshot('can_before_motion.json')
    start('driver', ['/usr/bin/python3', '-c', "import sys; sys.path.append('/home/johnwick/.local/lib/python3.10/site-packages'); from piper.piper_ctrl_single_node import main; main()", '--ros-args', '--log-level', 'WARN',
                    '-p', 'can_port:=can0', '-p', 'auto_enable:=false', '-p', 'gripper_exist:=true',
                    '-r', 'joint_states_single:=/joint_states', '-r', 'joint_ctrl_single:=/joint_commands'])
    start('visual', ['/usr/bin/python3', str(ROOT / 'original_observe_launch.py')])
    start('bag', ['ros2', 'bag', 'record', '-o', str(ROOT / 'motion_witness_bag'),
                  '/joint_states_feedback', '/joint_commands', '/brain_robot_grasp/arm_trajectory',
                  '/brain_robot_grasp/gripper_command', '/brain_robot_visual_control/state',
                  '/brain_robot_visual_control/reason', '/brain_robot_control/adapter_armed'])
    wait(lambda: latest is not None and time.time() - latest['epoch'] < .5, 18, 'fresh driver feedback')
    assert max(abs(a-b) for a,b in zip(latest['q'], measured['q_driver_rad'])) <= .001
    result = call('/visual_search_controller/set_parameters', SetParameters,
                  SetParameters.Request(parameters=[Parameter(name='stop_after_observe',
                  value=ParameterValue(type=ParameterType.PARAMETER_BOOL, bool_value=True))]))
    assert result.results[0].successful
    result = call('/visual_search_controller/get_parameters', GetParameters,
                  GetParameters.Request(names=['stop_after_observe']))
    assert result.values[0].bool_value
    report['stop_after_observe_readback'] = True
    result = call('/enable_srv', Enable, Enable.Request(enable_request=True))
    report['original_enable_true_requested'] = True
    assert result.enable_response
    enabled = sdk('sdk_after_enable')
    report['enabled_measured'] = enabled
    assert all(enabled['enabled'])
    assert max(abs(a-b) for a,b in zip(enabled['q_driver_rad'], measured['q_driver_rad'])) <= .001
    wait(lambda: latest is not None and time.time() - latest['epoch'] < .5, 26, 'fresh post-enable feedback')
    assert all(a <= q <= b for a,q,b in zip(lo,latest['q'],hi))
    trigger('/piper_jog_adapter/enable_motion')
    report['feedback_at_arm'] = dict(latest)
    trigger('/piper_jog_adapter/arm')
    armed = True
    wait(lambda: first_command is not None, 5, 'first adapter command')
    report['first_command'] = first_command
    assert max(abs(a-b) for a,b in zip(first_command['q'],report['feedback_at_arm']['q'])) <= .001
    trigger('/visual_search_controller/start')
    wait(lambda: 'OBSERVE_POSE_REACHED_STOPPED_BEFORE_SEARCH' in reason or 'FAILED' in reason,
         305, 'original observation completion')
    assert 'OBSERVE_POSE_REACHED_STOPPED_BEFORE_SEARCH' in reason
    report['observe_reached'] = True
    report['observe_feedback'] = dict(latest)
    trigger('/piper_jog_adapter/disarm')
    armed = False
    report['final_sdk'] = sdk('sdk_at_observation')
except BaseException as exc:
    report['error'] = repr(exc)
    print('SESSION STOP:', repr(exc), flush=True)
finally:
    if armed:
        for path in ['/visual_search_controller/stop', '/piper_jog_adapter/disarm']:
            try:
                trigger(path)
            except BaseException as exc:
                report['events'].append({'stop_service': path, 'error': repr(exc)})
    for name, proc, stream in reversed(jobs):
        report['events'].append({'name': name, 'final_exit_code': stop_owned(proc), 'epoch': time.time()})
        stream.close()
    report['all_owned_sources_exited'] = all(p.poll() is not None for _,p,_ in jobs)
    report['last_received_feedback'] = latest
    can_snapshot('can_after_motion.json')
    with (ROOT / 'execution_session.json').open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()
print(json.dumps(report), flush=True)
raise SystemExit(0 if report['observe_reached'] and report['error'] is None else 2)
