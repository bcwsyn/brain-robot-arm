"""Read closed original rosbag/SDK only; no device or ROS node initialization."""
import json
from pathlib import Path
import sqlite3
import sys
from collections import Counter

from rclpy.serialization import deserialize_message
from rosidl_runtime_py.utilities import get_message

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, '/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
from collect_calibration_sdk import summarize


def static_windows(path):
    packet = json.loads(path.read_text())
    rows, windows = packet['samples'], []
    for i in range(len(rows)):
        for j in range(i+30, len(rows)+1):
            part = rows[i:j]
            if all(row['fresh_after_passive_connection'] for row in part):
                quality = summarize(part)
                if quality['static_three_seconds_and_thirty_samples']:
                    windows.append({'slice': [i,j], 'quality': quality})
    return {'whole_original_quality': packet['quality'],
            'longest_original_contiguous_static_window': max(windows, key=lambda x: x['slice'][1]-x['slice'][0]) if windows else None}


def main():
    database = next((ROOT/'motion_witness_bag').glob('*.db3'))
    connection = sqlite3.connect(f'file:{database}?mode=ro', uri=True)
    topics = {i:(name,get_message(kind)) for i,name,kind in connection.execute('select id,name,type from topics')}
    counts, states, trajectories = Counter(), [], []
    command_first = command_last = feedback_last = None
    maximum_command_step = [0.0]*6
    previous = None
    names = [f'joint{i}' for i in range(1,7)]
    for topic, stamp, data in connection.execute('select topic_id,timestamp,data from messages order by timestamp,id'):
        name, kind = topics[topic]
        counts[name] += 1
        if name == '/brain_robot_grasp/gripper_command':
            raise AssertionError('Unexpected gripper command in observe-only bag')
        if name in ['/joint_commands','/joint_states_feedback']:
            message = deserialize_message(data,kind)
            values = dict(zip(message.name,message.position))
            if all(n in values for n in names):
                row = {'bag_stamp_ns':str(stamp),'q_rad':[values[n] for n in names],
                       'gripper_m':values.get('gripper')}
                if name == '/joint_commands':
                    assert 'gripper' not in values
                    command_first = command_first or row
                    command_last = row
                    if previous is not None:
                        maximum_command_step = [max(a,abs(b-c)) for a,b,c in zip(maximum_command_step,row['q_rad'],previous)]
                    previous = row['q_rad']
                else:
                    feedback_last = row
        elif name in ['/brain_robot_visual_control/state','/brain_robot_visual_control/reason']:
            message = deserialize_message(data,kind)
            states.append({'topic':name,'data':message.data,'bag_stamp_ns':str(stamp)})
        elif name == '/brain_robot_grasp/arm_trajectory':
            message = deserialize_message(data,kind)
            trajectories.append({'bag_stamp_ns':str(stamp),'points':len(message.points),
                'names':list(message.joint_names),'first_q_rad':list(message.points[0].positions),
                'last_q_rad':list(message.points[-1].positions),
                'planned_duration_s':message.points[-1].time_from_start.sec+message.points[-1].time_from_start.nanosec*1e-9})
    connection.close()
    state_values = [s['data'] for s in states if s['topic'].endswith('/state')]
    assert 'SEARCH' not in state_values and 'ALIGN' not in state_values
    assert len(trajectories) == 2 and trajectories[0]['points'] == 17
    assert trajectories[1]['points'] == 2
    assert trajectories[1]['first_q_rad'] == trajectories[1]['last_q_rad']
    trajectories[1]['identity'] = 'Original StopLocked -> PublishHoldTrajectoryLocked, not new movement'
    counts.setdefault('/brain_robot_grasp/gripper_command', 0)
    session = json.loads((ROOT/'execution_session.json').read_text())
    before = session['feedback_at_arm']['q']
    assert command_first['q_rad'] == before
    log = (ROOT/'visual.log').read_text(errors='replace')
    report = {'offline_only':True,'ROS_initialized':False,'CAN_accessed':False,
        'source_bag':str(database),'topic_counts':dict(counts),'controller_events':states,
        'no_search_or_align_in_bag':True,'original_trajectories':trajectories,
        'first_command':command_first,'last_command':command_last,'last_feedback':feedback_last,
        'first_arm_command_matches_real_feedback':True,'maximum_adjacent_command_step_rad':maximum_command_step,
        'SDK':{n:static_windows(ROOT/n) for n in ['sdk_after_manual_reset.json','sdk_after_enable.json','sdk_at_observation.json']},
        'shutdown_move_group_exit_minus11_in_original_log':'exit code -11' in log,
        'driver_final_exit_minus9':any(e.get('name')=='driver' and e.get('final_exit_code')==-9 for e in session['events']),
        'shutdown_failures_not_hidden_by_wrapper_rc0':True,
        'physical_disable_or_reset_sent':False,'gripper_commands_sent':False}
    with (ROOT/'motion_review.json').open('x') as stream:
        json.dump(report,stream,indent=2,allow_nan=False)
    print(json.dumps(report),flush=True)


if __name__ == '__main__':
    main()
