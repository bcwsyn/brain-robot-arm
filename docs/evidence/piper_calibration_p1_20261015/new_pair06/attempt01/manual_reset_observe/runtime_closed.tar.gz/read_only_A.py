"""Single bounded original RGB-D collection after original observe stack exits.

No target/quality changes; independent raw A, same-point link pending operator.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

SESSION_ROOT = Path(__file__).resolve().parent
ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else SESSION_ROOT
TESTS = Path('/mnt/hgfs/ub/brain_robot_arm/piper_ws/src/brain_robot_pick_place/test')
sys.path.insert(0, str(TESTS))
from collect_calibration_p0 import read_can, healthy_window

jobs = []
report = {'receive_only': True, 'motion_commands_sent': False, 'error': None,
          'events': [], 'requested_frames': 60, 'formal_pair_complete': False,
          'cube_unchanged_during_manual_reset': None, 'automatic_reopen': False}
camera_start, factory = None, None


def save(name, obj):
    with (ROOT / name).open('x') as stream:
        json.dump(obj, stream, indent=2, allow_nan=False)


def start(name, argv):
    stream = (ROOT / (name + '.log')).open('xb')
    proc = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    jobs.append((name, proc, stream))
    report['events'].append({'name': name, 'argv': argv, 'pid': proc.pid, 'epoch': time.time()})
    return proc


try:
    session = json.loads((SESSION_ROOT / 'execution_session.json').read_text())
    assert session['observe_reached'] and session['all_owned_sources_exited']
    before = read_can(); time.sleep(.2); after = read_can()
    save('A_can_before.json', {'before': before, 'after': after, 'healthy': healthy_window(before, after)})
    assert healthy_window(before, after), 'No receiving CAN; no automatic recovery'
    files = [TESTS / name for name in ['collect_static_rgbd.py', 'calibration_readonly_feedback.py']]
    save('A_source_SHA_before.json', {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    start('A_bridge', ['/usr/bin/python3', str(TESTS / 'calibration_readonly_feedback.py'),
                       '--duration-s', '60', '--output', str(ROOT / 'A_bridge.json')])
    code = ('import sys; sys.path.insert(0,' + repr(str(TESTS)) + '); '
            'from pathlib import Path; from collect_static_rgbd import collect; '
            'sys.exit(collect(Path(sys.argv[1]),43.,60,settle_s=3.,'
            'stop_on_feedback_loss=True,max_bytes=64<<20))')
    capture = start('A_capture', ['/usr/bin/python3', '-c', code, str(ROOT / 'A_capture')])
    time.sleep(3.3)
    camera_start = time.monotonic()
    report['camera_start_epoch'] = time.time()
    start('A_depth', ['ros2', 'launch', 'astra_camera', 'astra.launch.py'])
    while time.monotonic() - camera_start < 4.:
        if 'SENSOR_DEPTH is started' in (ROOT / 'A_depth.log').read_text(errors='replace'):
            break
        time.sleep(.05)
    start('A_color', ['/opt/ros/humble/lib/image_tools/cam2image', '--ros-args',
                     '-p', 'burger_mode:=false', '-p', 'device_id:=0', '-p', 'frequency:=5.0',
                     '-p', 'width:=320', '-p', 'height:=240',
                     '-p', 'frame_id:=camera_color_optical_frame', '-r', 'image:=/camera/color/image_raw'])
    while time.monotonic() - camera_start < 39.:
        rows = ROOT / 'A_capture/observer.jsonl'
        if factory is None and rows.exists() and rows.stat().st_size:
            report['factory_after_first_actual_RGBD_epoch'] = time.time()
            factory = start('A_factory', ['/usr/bin/python3',
                '/home/johnwick/brain_robot_logs/calibration_stage1_activated_20261014.kfNDAQ/capture_factory_metadata.py',
                str(ROOT / 'A_factory.json')])
        if capture.poll() is not None and (factory is None or factory.poll() is not None):
            break
        time.sleep(.05)
    report['capture_returncode_before_cleanup'] = capture.poll()
    report['end_reason'] = 'collectors_finished' if capture.poll() is not None else 'single_39s_camera_deadline'
except BaseException as exc:
    report['error'] = repr(exc)
finally:
    for name, proc, _ in jobs:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGINT)
    grace = time.monotonic() + 1.5
    while any(p.poll() is None for _,p,_ in jobs) and time.monotonic() < grace:
        time.sleep(.02)
    for name, proc, stream in jobs:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGKILL)
        report['events'].append({'name': name, 'exit_code': proc.wait(timeout=1)})
        stream.close()
    report['all_owned_sources_exited'] = all(p.poll() is not None for _,p,_ in jobs)
    report['camera_elapsed_s_including_cleanup'] = None if camera_start is None else time.monotonic() - camera_start
    if (ROOT / 'A_capture/summary.json').exists():
        report['capture_summary'] = json.loads((ROOT / 'A_capture/summary.json').read_text())
    save('A_source_SHA_after.json', {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files})
    save('A_can_after.json', read_can())
    save('A_execution.json', report)
print(json.dumps(report), flush=True)
raise SystemExit(0 if report.get('capture_summary', {}).get('saved_frames') == 60 and report['error'] is None else 2)
