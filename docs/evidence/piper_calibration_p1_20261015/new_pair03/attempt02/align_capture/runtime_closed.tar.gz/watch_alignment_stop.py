#!/usr/bin/python3
"""This run only: observe original state, then call original stop/disarm services.
No joint, pose, gripper, enable or trajectory publishers; no production edits.
"""
import json
from pathlib import Path
import time
import rclpy
from rclpy.qos import QoSProfile, DurabilityPolicy
from std_msgs.msg import String
from std_srvs.srv import Trigger
rclpy.init()
node = rclpy.create_node('calibration_alignment_stop_witness')
out = Path(__file__).parent
stream = (out / 'alignment_state_witness.jsonl').open('x')
state = {'latest': None, 'stop': None}
def receive(msg):
    stream.write(json.dumps({'receipt_epoch':time.time(),'state':msg.data})+'\n')
    stream.flush()
    state['latest'] = msg.data
    if msg.data in ('GRASP_READY','FAULT'):
        state['stop'] = msg.data
sub = node.create_subscription(String,'/brain_robot_visual_control/state',receive,
    QoSProfile(depth=1,durability=DurabilityPolicy.TRANSIENT_LOCAL))
begin = time.monotonic()
while rclpy.ok() and not state['stop'] and time.monotonic()-begin < 125:
    rclpy.spin_once(node,timeout_sec=.1)
results = {'stop_state': state['stop'], 'last_state': state['latest'],
    'bounded_timeout':state['stop'] is None, 'epoch':time.time(), 'calls':[]}
for name in ('/visual_search_controller/stop','/piper_jog_adapter/disarm'):
    client=node.create_client(Trigger,name)
    if not client.wait_for_service(timeout_sec=3):
        results['calls'].append({'service':name,'response':None});continue
    future=client.call_async(Trigger.Request())
    rclpy.spin_until_future_complete(node,future,timeout_sec=5)
    response=future.result() if future.done() else None
    results['calls'].append({'service':name,
        'success':response.success if response else False,
        'message':response.message if response else 'timeout'})
stream.close()
(out/'alignment_stop_result.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results),flush=True)
node.destroy_node()
rclpy.shutdown()

