#!/usr/bin/env python3
"""Simulation-only cup integration: learned sizing, physical contact and force loop."""
import argparse
from contextlib import nullcontext
import fcntl
import json
import math
import os
from pathlib import Path
import socket
import sys
import hashlib
import tarfile
import time
import xml.etree.ElementTree as ET

import numpy as np
import yaml

from visual_sim_console import VisualSession, Keyboard, BatchKeyboard, QuitRequested

WS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(WS / 'src/brain_robot_pick_place/scripts'))
from cup_geometry import CupSpec, write_model
from contact_force_feedback import target_normal_force


class CupSession(VisualSession):
    def __init__(self, args, keyboard):
        super().__init__(args, keyboard)
        from std_msgs.msg import String, Bool
        from sensor_msgs.msg import Image
        from rclpy.qos import qos_profile_sensor_data
        from geometry_msgs.msg import TransformStamped
        from tf2_ros import StaticTransformBroadcaster
        from scipy.spatial.transform import Rotation
        self.clients['start'] = self.node.create_client(self.Trigger, '/grasp_lift_executor/execute')
        self.clients['stop'] = self.node.create_client(self.Trigger, '/grasp_lift_executor/stop')
        self.vision, self.vision_time, self.force_data = None, 0., None
        self.executor_ready = False
        self.contact_packets_saved = set()
        sources = ['src/brain_robot_pick_place/src/grasp_lift_executor.cpp',
                   'src/brain_robot_pick_place/scripts/cup_force_gripper_node.py',
                   'src/brain_robot_pick_place/scripts/contact_force_feedback.py',
                   'src/brain_robot_pick_place/scripts/cup_perception.py',
                   'src/brain_robot_pick_place/scripts/cup_geometry.py',
                   'src/brain_robot_pick_place/scripts/yolo_cup_target_node.py',
                   'src/brain_robot_pick_place/scripts/scene_manager_node.py',
                   'scripts/cup_grasp_console.py', 'src/brain_robot_pick_place/launch/cup_task.launch.py']
        with tarfile.open(self.output / 'source_snapshot.tar.gz', 'w:gz') as archive:
            for name in sources:
                archive.add(self.workspace / name, arcname=name)
        (self.output / 'source_hashes.json').write_text(json.dumps(
            {name: hashlib.sha256((self.workspace / name).read_bytes()).hexdigest() for name in sources}, indent=2) + '\n')
        self.subscriptions.extend([
            self.node.create_subscription(String, '/brain_robot_vision/cup_diagnostic', self.on_vision, 10),
            self.node.create_subscription(String, '/cup_gripper/diagnostic', self.on_force, 10),
            self.node.create_subscription(Image, '/cup_probe/view1/camera/image_raw', self.on_camera,
                                          qos_profile_sensor_data),
            self.node.create_subscription(Image, '/brain_robot_vision/cup_debug_image',
                                          lambda _: self.mark_image('detection'), qos_profile_sensor_data),
        ])
        # Fixed external RGB-D calibration. Object truth is never broadcast as a target TF.
        xyz, target = np.array([.08, -.4, .24]), np.array([.40, -.10, .12])
        forward = (target - xyz) / np.linalg.norm(target - xyz)
        yaw = math.atan2(forward[1], forward[0])
        right = np.array([math.sin(yaw), -math.cos(yaw), 0.])
        rotation = np.column_stack((right, np.cross(forward, right), forward))
        self.camera_xyz = xyz.tolist()
        self.camera_pitch, self.camera_yaw = -math.asin(forward[2]), yaw
        self.broadcaster = StaticTransformBroadcaster(self.node)
        tf = TransformStamped()
        tf.header.frame_id, tf.child_frame_id = 'world', 'cup_observer_optical'
        tf.transform.translation.x, tf.transform.translation.y, tf.transform.translation.z = xyz.tolist()
        q = Rotation.from_matrix(rotation).as_quat()
        tf.transform.rotation.x, tf.transform.rotation.y, tf.transform.rotation.z, tf.transform.rotation.w = q.tolist()
        self.broadcaster.sendTransform(tf)
        self.world = self.make_world()
        (self.output / 'scope.json').write_text(json.dumps(dict(
            camera='fixed external RGB-D with static calibration',
            target='YOLO learned mask and depth; no Gazebo pose for grasp target',
            retention='Gazebo object height and contacts used only for independent acceptance',
            total_stroke_m=.100, force_band_n=[2.5, 3.5], hard_force_limit_n=5.,
            body_diameter_truth_m=args.diameter_mm / 1000,
            mass_kg=.080, mass_is_measured=False, wall_thickness_m=.002), indent=2) + '\n')

    def make_world(self):
        root = ET.parse(self.workspace / 'validation/grasp_validation.world')
        physics = root.getroot().find('world/physics')
        solver = ET.SubElement(ET.SubElement(physics, 'ode'), 'solver')
        ET.SubElement(solver, 'type').text = 'quick'
        ET.SubElement(solver, 'iters').text = '200'
        x, y, z = self.camera_xyz
        camera = ET.fromstring(f'''<model name="cup_observer"><static>true</static>
          <pose>{x} {y} {z} 0 {self.camera_pitch} {self.camera_yaw}</pose><link name="camera">
          <sensor name="rgbd" type="depth"><always_on>true</always_on><update_rate>5</update_rate>
          <camera><horizontal_fov>1.0471975512</horizontal_fov><image><width>640</width><height>480</height>
          <format>R8G8B8</format></image><clip><near>.05</near><far>2</far></clip></camera>
          <plugin name="cup_observer_rgbd" filename="libgazebo_ros_camera.so">
          <ros><namespace>/cup_probe/view1</namespace></ros><camera_name>camera</camera_name>
          <frame_name>cup_observer_optical</frame_name><min_depth>.05</min_depth><max_depth>2</max_depth>
          </plugin></sensor></link></model>''')
        root.getroot().find('world').append(camera)
        path = self.output / 'cup_integration.world'
        root.write(path, encoding='utf-8', xml_declaration=True)
        return path

    def on_vision(self, msg):
        self.vision, self.vision_time = json.loads(msg.data), time.monotonic()
        self.record(cup_vision=self.vision)

    def on_camera(self, msg):
        if msg.header.frame_id == 'cup_observer_optical':
            super().on_camera(msg)

    def on_force(self, msg):
        self.force_data = json.loads(msg.data)
        if self.active_run:
            self.record(cup_force=self.force_data)
            self.active_run.setdefault('force_samples', []).append(self.force_data)

    def on_contacts(self, msg, index):
        super().on_contacts(msg, index)
        value, count = target_normal_force(msg, self.model, require_step_time=True)
        if value > .5 and index not in self.contact_packets_saved:
            from rosidl_runtime_py.convert import message_to_ordereddict
            self.contact_packets_saved.add(index)
            (self.output / f'raw_contacts_link{index+7}.json').write_text(json.dumps(dict(
                latest_step_force_n=value, latest_step_points=count,
                message=message_to_ordereddict(msg)), indent=2) + '\n')

    def on_grasp(self, msg):
        super().on_grasp(msg)
        self.state['visual'] = 'IDLE' if msg.data in ('COMPLETE', 'WAITING_FOR_GRASP_REQUEST') else 'GRASPING'

    def on_diagnostic(self, msg):
        if msg.data == 'CUP_EXECUTOR_READY':
            self.executor_ready = True
        super().on_diagnostic(msg)

    def prepare_scene_profile(self):
        path = super().prepare_scene_profile()
        profile = yaml.safe_load(path.read_text())
        spec = CupSpec(body_diameter_m=self.args.diameter_mm / 1000,
                       mouth_diameter_m=self.args.diameter_mm * .84 / 1000)
        model = write_model(self.output / f'cup_model_{self.scene_index:03d}', spec, name=self.model,
                            compact_bottom=True)
        profile['scene_manager']['ros__parameters'].update(cup_radius=spec.body_diameter_m / 2,
            cup_height=spec.height_m, cup_z=spec.height_m / 2, cup_model_sdf=str(model))
        path.write_text(yaml.safe_dump(profile, sort_keys=False))
        self.expected_pose[2] = spec.height_m / 2
        task = yaml.safe_load(self.physics_task_profile.read_text())
        task['grasp_lift_executor']['ros__parameters'].update(
            adaptive_cup_enabled=True, known_position_task=False, auto_execute=False,
            target_point_topic='/brain_robot_vision/cup_grasp_point',
            target_size_topic='/brain_robot_vision/grasp_width',
            depth_valid_topic='/brain_robot_vision/cup_target_valid',
            physics_object_width_m=0., top_down_tilt_candidates=[1.2, 1.0, .70],
            gripper_tip_offset_m=.130, grasp_center_offset_m=.130,
            linear_approach_velocity_scaling=.03,
            top_down_pregrasp_clearance_m=.10)
        self.physics_task_profile.write_text(yaml.safe_dump(task, sort_keys=False))
        return path

    def bootstrap(self):
        self.mode = 'LOADING'
        self.generation += 1
        self.clear_state()
        self.say('1/5', '加载 Gazebo 虚拟机械臂、物理指垫和固定 RGB-D 相机…')
        self.launch_ros('gazebo', 'brain_robot_pick_place', 'wrist_camera_gazebo.launch.py',
                        'gui:=false', 'physics_grasp:=true', 'physics_jaw_kp:=300',
                        'physics_jaw_kd:=0.5', 'world:=' + str(self.world))
        client = self.clients['controllers']
        self.wait(client.service_is_ready, 60, '控制器服务')
        discovered = time.monotonic()
        self.wait(lambda: time.monotonic() - discovered >= 2., 3, '控制器服务发现稳定')
        future = None
        def active():
            nonlocal future
            if future is None:
                future = client.call_async(self.ListControllers.Request())
            if not future.done():
                return False
            controllers = {c.name for c in future.result().controller if c.state == 'active'}
            future = None
            return {'joint_state_broadcaster', 'arm_controller', 'gripper_controller', 'gripper8_controller'} <= controllers
        self.wait(active, 60, '虚拟控制器激活')
        self.wait(lambda: self.joints is not None and max(abs(v) for v in self.joints) < .001,
                  20, '虚拟零位反馈')
        if not self.args.headless:
            self.launch('gazebo-window', ['gzclient'])
        self.say('2/5', '加载 MoveIt…')
        self.launch_ros('moveit', 'piper_with_gripper_moveit', 'piper_moveit.launch.py', 'start_rviz:=false')
        self.wait(self.clients['planning'].service_is_ready, 60, 'MoveIt 场景服务')
        if not self.args.headless:
            layout = (self.workspace / 'config/visual_grasp.rviz').read_text().replace(
                '/brain_robot_vision/debug_image', '/brain_robot_vision/cup_debug_image').replace(
                '/wrist_camera/wrist_camera/image_raw', '/cup_probe/view1/camera/image_raw')
            rviz = self.output / 'cup_view.rviz'
            rviz.write_text(layout)
            self.launch('rviz-window', ['rviz2', '-d', str(rviz), '--ros-args', '-r',
                '__node:=cup_grasp_viewer', '-p', 'use_sim_time:=true'],
                dict(os.environ, LIBGL_ALWAYS_SOFTWARE='1', __GLX_VENDOR_LIBRARY_NAME='mesa'))
        self.say('3/5', '创建 200 mm 中空台阶杯…')
        self.load_scene()
        self.say('4/5', '加载训练后的 YOLO 与 RGB-D 估径…')
        self.launch('yolo', [str(self.workspace / '.venv-yolo/bin/python'), '-s',
            str(self.workspace / 'src/brain_robot_pick_place/scripts/yolo_cup_target_node.py'),
            '--ros-args', '-p', 'use_sim_time:=true', '-p',
            'grasp_height_fraction:=0.60', '-p',
            'model:=' + str(self.workspace / 'models/cup_yolov8n_seg_v2.pt'),
            '-p', 'rgb_topic:=/cup_probe/view1/camera/image_raw',
            '-p', 'depth_topic:=/cup_probe/view1/camera/depth/image_raw',
            '-p', 'camera_info_topic:=/cup_probe/view1/camera/camera_info'])
        self.wait(lambda: self.vision is not None and self.vision['status'] == 'VALID'
                  and time.monotonic() - self.vision_time < .5, 50, 'YOLO 单杯定位与估径')
        self.record(initial_cup_vision=self.vision)
        self.say('5/5', '加载独立水杯执行器与接触力闭环…')
        self.launch_ros('task', self.package, 'cup_task.launch.py', 'params_file:=' + str(self.physics_task_profile))
        self.wait(lambda: self.executor_ready and self.force_data is not None and
                  all(self.clients[k].service_is_ready() for k in ('start', 'stop', 'placement')),
                  40, '水杯执行器')
        self.state['visual'] = 'IDLE'
        self.mode = 'READY'
        self.set_placement(self.selected_zone)
        self.say('就绪', 'S 视觉估径抓取 | 1/2 放置区 | R 复位 | X 停止 | Q 退出')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--headless', action='store_true')
    parser.add_argument('--seed', type=int)
    parser.add_argument('--batch-trials', type=int, default=0)
    parser.add_argument('--diameter-mm', type=float, default=75.)
    parser.add_argument('--physics-negative', choices=['miss', 'drop', 'stop'])
    args = parser.parse_args()
    if not 35 <= args.diameter_mm <= 95 or not 0 <= args.batch_trials <= 20:
        parser.error('Supported specimen diameter 35..95 mm; batch count 0..20')
    if args.batch_trials and (not args.headless or args.seed is None):
        parser.error('Batch requires --headless and --seed')
    if not args.batch_trials and not sys.stdin.isatty():
        parser.error('Interactive mode needs a terminal')
    args.task, args.physics = 'cup', True
    (WS / 'log').mkdir(exist_ok=True)
    with (WS / 'log/cup_grasp.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 11485))
        session = None
        keyboard = BatchKeyboard() if args.batch_trials else Keyboard()
        try:
            with (nullcontext(keyboard) if args.batch_trials else keyboard):
                session = CupSession(args, keyboard)
                session.run()
        except (KeyboardInterrupt, QuitRequested):
            return 0
        except Exception as error:
            print(f'Cup simulation failed: {error}', file=sys.stderr, flush=True)
            return 1
        finally:
            if session:
                session.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
